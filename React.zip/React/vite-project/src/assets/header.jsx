import React from "react";
function Header()
{
    return (
        <div>
            <header>
            <h1>THis is a react</h1>
            <p>React is a library</p>
            </header>
        </div>
    )
}
export default Header;